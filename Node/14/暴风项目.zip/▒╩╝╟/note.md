1.下一个插件  Easy Less

2.文件 => 首选项 => 设置 => 输入easy => 在setting.json中编辑

3.修改下面的内容

 "less.compile": {
        "compress": false, // true => remove surplus whitespace
        "sourceMap": false, // true => generate source maps (.css.map files)
        "out": "../css/", // false => DON'T output .css files (overridable per-file, see below)
    }