//搜索栏
~ function() {
    var headerMiddle = utils.getClass('header-middle')[0];
    var input = headerMiddle.getElementsByTagName('input')[0];
    var headerMiddleBox = utils.getClass('header-middle-box', headerMiddle)[0];
    var lis = headerMiddleBox.getElementsByTagName('li')
    var val = input.value;
    input.onfocus = function() {
        if (input.value == val) {
            input.value = '';
        }
        headerMiddleBox.style.display = 'block'
        for (var i = 0; i < lis.length; i++) {
            lis[i].onmouseover = function() {
                input.value = this.innerHTML
            }
        }
    }
    input.onblur = function() {
        headerMiddleBox.style.display = 'none'

    }
}()

//滚动栏
~ function() {
    var bannerNav = utils.getClass("banner-nav-inner-right")[0];
    var bannerScroll = utils.getClass("banner-nav-inner-right-scroll")[0];
    var bannerNavWrap = utils.getClass("banner-nav-inner")[0];
    var myUl = bannerNavWrap.getElementsByTagName('ul')[0];

    var scrollTop = 0;
    bannerScroll.onmousedown = function(ev) {
        ev = ev || window.event;
        var y = ev.clientY - this.offsetTop;
        document.onmousemove = function(ev) {
            ev = ev || window.event;
            scrollTop = ev.clientY - y;
            if (scrollTop <= 0) {
                scrollTop = 0;
            } else if (scrollTop >= bannerNav.offsetHeight - bannerScroll.offsetHeight) {
                scrollTop = bannerNav.offsetHeight - bannerScroll.offsetHeight
            }
            bannerScroll.style.top = scrollTop + 'px';
            myUl.style.top = (myUl.offsetHeight - bannerNav.offsetHeight) / (bannerNavWrap.offsetHeight - bannerScroll.offsetHeight) * (-scrollTop) + 'px';
        }
        document.onmouseup = function() {
            document.onmousemove = document.onmouseup = null;
        }
    }

    bannerNavWrap.onmousewheel = function(ev) {
        ev = ev || event;
        scrollMove(ev);
    }

    bannerNavWrap.addEventListener('DOMMouseScroll', function(ev) {
        ev == ev || event;
        scrollMove(ev);
    })

    function scrollMove(ev) {
        // ev.preventDefault ? ev.preventDefault() : retrunValue = false;
        ev.preventDefault ? ev.preventDefault() : returnValue = false;
        if (wheelEvent(ev) > 0) {
            scrollTop -= 15;
        } else {
            scrollTop += 15;
        }

        if (scrollTop <= 0) {
            scrollTop = 0;
        } else if (scrollTop >= bannerNav.offsetHeight - bannerScroll.offsetHeight) {
            scrollTop = bannerNav.offsetHeight - bannerScroll.offsetHeight
        }
        bannerScroll.style.top = scrollTop + 'px';
        myUl.style.top = (myUl.offsetHeight - bannerNav.offsetHeight) / (bannerNavWrap.offsetHeight - bannerScroll.offsetHeight) * (-scrollTop) + 'px';
    }


    function wheelEvent(ev) {
        if (ev.wheelDelta) {
            return ev.wheelDelta;
        } else {
            return ev.detail * (-40)
        }
    }
}()

// 猜你喜欢数据绑定
~ function() {
    var contentInner = utils.getClass('content-inner')[0];
    var contentLike = utils.getClass('content-like', contentInner)[0];
    var myUl = contentLike.getElementsByTagName('ul')[0];
    var imgs = myUl.getElementsByTagName('img');
    ajax({
        url: "data/data1.json",
        dataType: "JSON",
        success: function(jsonData) {
            getGuess(jsonData.guess)
        }
    })

    function getGuess(jsonData) {
        var str = '';
        for (var i = 0; i < jsonData.length; i++) {
            var data = jsonData[i];
            str += '<li><div class="img"><img src="" trueSrc="' + data.img + '" ></div><div>' + data.title + ' <span>' + data.score + '</span></div><p>' + data.details + '</p></li>'
        }
        myUl.innerHTML = str;
    }

    // window.onscroll = function(ev) {
    //     ev = ev || this.event;
    //     for (var i = 0; i < imgs.length; i++) {
    //         var curImg = imgs[i];
    //         lazyImg(curImg)
    //         console.log(1)
    //     }
    // }
    window.addEventListener('scroll', function(ev) {
        ev = ev || this.event;
        for (var i = 0; i < imgs.length; i++) {
            var curImg = imgs[i];
            lazyImg(curImg)
        }
    })


}();

function lazyImg(curImg) {
    var y = utils.offset(curImg.parentNode).top + curImg.parentNode.offsetHeight;
    var scrTop = document.documentElement.scrollTop + document.documentElement.clientHeight;
    if (scrTop >= y) {
        var oImg = new Image();
        oImg.src = curImg.getAttribute('trueSrc');
        oImg.onload = function() {
            curImg.src = oImg.src;
            curImg.style.display = 'block';
            utils.fadeIn(curImg);
            oImg = null;
        }
    }
}
//热门数据绑定
~ function() {
    var contentBottom = utils.getClass('content-bottom')[0];
    var contentHot = utils.getClass('content-hot', contentBottom)[0];
    var myUl = contentHot.getElementsByTagName('ul')[0];
    var imgs = myUl.getElementsByTagName('img');

    ajax({
        url: "data/data1.json",
        dataType: "JSON",
        success: function(jsonData) {
            getGuess(jsonData.hot_recommend)

        }
    })

    function getGuess(jsonData) {
        var str = '';
        for (var i = 0; i < jsonData.length; i++) {
            var data = jsonData[i];
            str += '<li><div class="img1"><img src="" trueSrc="' + data.img + '" ></div><p>' + data.title + '</p></li>'
        }
        myUl.innerHTML = str;
    }

    window.onscroll = function(ev) {
        ev = ev || this.event;
        for (var i = 0; i < imgs.length; i++) {
            var curImg = imgs[i];
            lazyImg(curImg)
        }
    }

    // function lazyImg(curImg) {
    //     var y = utils.offset(curImg.parentNode).top + curImg.parentNode.offsetHeight;
    //     var scrTop = document.documentElement.scrollTop + document.documentElement.clientHeight;
    //     if (scrTop >= y) {
    //         var oImg = new Image();
    //         oImg.src = curImg.getAttribute('trueSrc');
    //         oImg.onload = function() {
    //             curImg.src = oImg.src;
    //             curImg.style.display = 'block';
    //             utils.fadeIn(curImg);
    //             oImg = null;
    //         }
    //     }
    // }

}();

//电影榜交互
~ function() {
    var contentFlm = utils.getClass('content-film')[0];
    var lis = contentFlm.getElementsByTagName('li');

    for (var i = 0; i < lis.length; i++) {
        lis[i].onmouseover = function() {
            for (var j = 0; j < lis.length; j++) {
                lis[j].className = '';
            }
            this.className = 'box';
        }
    }
}();


//评论区域数据绑定
~ function() {
    var comment = document.getElementById('comment');
    var myUl = comment.getElementsByTagName('ul')[0];
    var count = document.getElementById('count');
    var totalPage = document.getElementById('totalPage');

    var n = 1,
        page = 0;
    ajax({
        method: 'get',
        url: 'http://127.0.0.1:100/getData?n=' + n,
        dataType: 'JSON',
        success: function(jsonData) {
            var data = jsonData.data;
            page = jsonData.total
            totalPage.innerHTML = page;
            bindData(data);

            comment.onclick = function(ev) {
                ev = ev || event;
                var target = ev.target || window.srcElement;
                var tarInner = target.innerHTML;
                if (target.tagName.toUpperCase() === 'SPAN') {
                    if (tarInner === '上一页') {
                        if (n === 1) return;
                        n--;
                        count.value = n;
                    }

                    if (tarInner === '下一页') {
                        if (n === page) return;
                        n++;
                        count.value = n;
                    }

                    if (tarInner === '确定') {
                        if (isNaN(parseInt(count.value))) return;
                        n = parseInt(count.value);

                    }
                    ajax({
                        method: 'get',
                        url: 'http://127.0.0.1:100/getData?n=' + n,
                        dataType: 'JSON',
                        success: function(jsonData) {
                            var data = jsonData.data;
                            bindData(data);
                        }
                    })
                }
            }
            count.onkeyup = function(ev) {
                ev = ev || event;
                if (ev.keyCode === 13) {
                    n = parseInt(this.value);
                    ajax({
                        method: 'get',
                        url: 'http://127.0.0.1:100/getData?n=' + n,
                        dataType: 'JSON',
                        success: function(jsonData) {
                            var data = jsonData.data;
                            bindData(data);
                        }
                    })
                }

            }
        }

    })



    function bindData(data) {
        var str = '';
        for (var i = 0; i < data.length; i++) {
            var curData = data[i];
            str += '<li class="cliearfix">' +
                '<div class="comment_user cliearfix">' +
                '<img class="fl" src="' + curData.imgIco + '">' +
                '<div class="fl">' +
                '<p class="name">' + curData.userId + '</p>' +
                '<p class="time">' + curData.date + ' ' + curData.time + '</p>' +
                '</div>' +
                '</div>' +
                '<p class="comment_content">' + curData.content +
                '</p>' +
                '<p class="dian fr">' +
                '<a href="#" class="dian_j">举报</a>' +
                '<a href="#" class="dian_icon"></a>' +
                '<span class="dian_count">' + curData.count + '</span>' +
                '</p>' +
                '</li>'
        }
        myUl.innerHTML = str;
    }
}()


//用户登录后
;
(function() {
    var headerRight = utils.getClass('header-right')[0];
    var login = utils.getClass('login', headerRight)[0];
    var userInformation = utils.getClass('userInformation', headerRight)[0];

    var user = utils.getCookie('userName');
    var pass = utils.getCookie('passWord');
    if (user || pass) {
        login.style.display = 'none';
        userInformation.style.display = 'block';
        userInformation.innerHTML = '<span></span><i><a href="#">' + user + '</a></i>'
    }
}())